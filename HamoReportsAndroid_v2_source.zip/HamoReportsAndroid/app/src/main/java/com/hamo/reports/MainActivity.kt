package com.hamo.reports

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.Locale

private val Gold = Color(0xFFFFC857)
private val Flame = Color(0xFFFF7A18)
private val Ink = Color(0xFF08090D)
private val Panel = Color(0xFF151821)
private val Muted = Color(0xFF9AA3B2)
private val Green = Color(0xFF25D366)

data class ReportItem(val number: String, val category: String, val note: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        val prefs = getSharedPreferences("hamo_local", MODE_PRIVATE)
        setContent {
            var unlocked by remember { mutableStateOf(false) }
            var pin by remember { mutableStateOf("") }
            var storedPin by remember { mutableStateOf(prefs.getString("pin", null)) }
            var reports by remember {
                mutableStateOf(prefs.getStringSet("reports", emptySet())!!.mapNotNull {
                    val p = it.split("|", limit = 3)
                    if (p.size == 3) ReportItem(p[0], p[1], p[2]) else null
                })
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = Flame, background = Ink, surface = Panel)) {
                if (!unlocked) {
                    LockScreen(pin, { pin = it }, storedPin != null, {
                        if (storedPin == null && pin.length >= 4) {
                            prefs.edit().putString("pin", pin).apply(); storedPin = pin; pin = ""; unlocked = true
                        } else if (pin == storedPin) { pin = ""; unlocked = true }
                    }, { showBiometric { unlocked = true } })
                } else {
                    HomeScreen(reports, { item ->
                        reports = reports + item
                        prefs.edit().putStringSet("reports", reports.map { "${it.number}|${it.category}|${it.note}" }.toSet()).apply()
                    }, { tts?.speak("نورت تطبيق حمو الموضوع يا كبير", TextToSpeech.QUEUE_FLUSH, null, "welcome") })
                }
            }
        }
    }
    private fun showBiometric(onSuccess: () -> Unit) {
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("خزنة حمو الموضوع")
            .setSubtitle("أكد هويتك بالبصمة").setNegativeButtonText("إلغاء").build())
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun GlowButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
        shape = RoundedCornerShape(14.dp), modifier = Modifier.height(50.dp)) {
        Icon(icon, null); Spacer(Modifier.width(8.dp)); Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LockScreen(pin: String, onPin: (String) -> Unit, hasPin: Boolean, onUnlock: () -> Unit, onBiometric: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF211608), Ink, Color(0xFF090D16)))),
        contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(104.dp).border(2.dp, Gold, RoundedCornerShape(30.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Security, null, tint = Gold, modifier = Modifier.size(58.dp))
            }
            Spacer(Modifier.height(18.dp))
            Text("حمو الموضوع", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Text("WHATSAPP REPORTS  •  برعاية حمو الموضوع", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(34.dp))
            Text(if (hasPin) "بوابة الدخول" else "أنشئ رمز الدخول", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(if (hasPin) "أدخل الرمز للمتابعة" else "أربع خانات أو أكثر", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(pin, onPin, label = { Text("الرقم السري") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            GlowButton(if (hasPin) "فتح البوابة" else "حفظ وبدء", Icons.Default.LockOpen, onUnlock)
            TextButton(onClick = onBiometric) { Icon(Icons.Default.Fingerprint, null, tint = Gold); Spacer(Modifier.width(6.dp)); Text("الدخول بالبصمة", color = Gold) }
            Text("بياناتك التجريبية محفوظة على الجهاز", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun HomeScreen(reports: List<ReportItem>, onAdd: (ReportItem) -> Unit, onWelcome: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("تهديد") }
    var note by remember { mutableStateOf("") }
    val tabs = listOf("الرئيسية", "البلاغات", "الحماية", "الإحصائيات")
    Scaffold(containerColor = Ink, bottomBar = {
        NavigationBar(containerColor = Panel, contentColor = Gold) {
            val icons = listOf(Icons.Default.Dashboard, Icons.Default.Assignment, Icons.Default.Shield, Icons.Default.BarChart)
            tabs.forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) },
                    label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Ink, selectedTextColor = Gold, indicatorColor = Gold, unselectedIconColor = Muted, unselectedTextColor = Muted))
            }
        }
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("أهلاً بيك يا قائد 👑", color = Muted, fontSize = 13.sp)
                        Text("حمو الموضوع", color = Gold, fontSize = 29.sp, fontWeight = FontWeight.Black)
                        Text("مركز إدارة الحماية والتوثيق", color = Color.White, fontSize = 12.sp)
                    }
                    Box(Modifier.size(54.dp).border(1.dp, Gold, RoundedCornerShape(18.dp)).background(Panel, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(30.dp))
                    }
                }
            }
            if (tab == 0) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF38250C), Color(0xFF171923)))).padding(18.dp)) {
                            Column {
                                Text("⚡ مركز القيادة", color = Gold, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                                Text("وثّق الوقائع، راجع أدلتك، وحافظ على أمان حسابك.", color = Color.White, fontSize = 13.sp)
                                Spacer(Modifier.height(14.dp))
                                GlowButton("رسالة ترحيب", Icons.Default.VolumeUp, onWelcome)
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile("سجلات البلاغات", reports.size.toString(), Icons.Default.Folder, Modifier.weight(1f))
                        StatTile("مركز الحماية", "نشط", Icons.Default.VerifiedUser, Modifier.weight(1f))
                    }
                }
                item { SectionTitle("الوصول السريع", "⚙") }
                item { QuickCard("إدارة البلاغات", "سجّل واقعة واحتفظ بوصفها", Icons.Default.Assignment, Green) { tab = 1 } }
                item { QuickCard("مركز الحماية", "إرشادات لتأمين حسابك", Icons.Default.Security, Gold) { tab = 2 } }
                item { QuickCard("لوحة الإحصائيات", "تابع عدد السجلات المحفوظة", Icons.Default.BarChart, Flame) { tab = 3 } }
            } else if (tab == 1) {
                item { SectionTitle("سجل البلاغات", "📁") }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("إضافة واقعة جديدة", color = Gold, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            OutlinedTextField(number, { number = it }, label = { Text("رقم واتساب أو معرّف") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(category, { category = it }, label = { Text("نوع الواقعة") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(note, { note = it }, label = { Text("تفاصيل الواقعة والأدلة") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                            GlowButton("حفظ في السجل", Icons.Default.Save) {
                                if (number.isNotBlank() && note.isNotBlank()) {
                                    onAdd(ReportItem(number.trim(), category.trim(), note.trim())); number = ""; note = ""
                                }
                            }
                            Text("استخدم السجل لتوثيق الوقائع الحقيقية فقط. لا يتم إرسال بلاغات من التطبيق.", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                if (reports.isEmpty()) item { EmptyState("لسه مفيش سجلات", "أضف أول واقعة موثقة من النموذج أعلاه.") }
                items(reports) { r ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(r.number, color = Gold, fontWeight = FontWeight.Bold)
                            Text(r.category, color = Green, fontSize = 12.sp)
                            Text(r.note, color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            } else if (tab == 2) {
                item { SectionTitle("مركز الحماية", "🛡") }
                item { QuickCard("فعّل التحقق بخطوتين", "من إعدادات واتساب ← الحساب ← التحقق بخطوتين.", Icons.Default.VerifiedUser, Green) {} }
                item { QuickCard("احمِ رمز التسجيل", "لا تشارك رمز SMS أو رمز PIN مع أي شخص.", Icons.Default.Password, Gold) {} }
                item { QuickCard("راجع الأجهزة المرتبطة", "سجّل الخروج من أي جهاز لا تعرفه.", Icons.Default.Devices, Flame) {} }
                item { QuickCard("احتفظ بالأدلة", "احفظ الرسائل والتواريخ ولقطات الشاشة الأصلية.", Icons.Default.Folder, Gold) {} }
                item { Text("تنبيه: التطبيق لا يتصل بواتساب ولا يمنع الحظر أو يضمن إزالة القيود.", color = Muted, fontSize = 12.sp) }
            } else {
                item { SectionTitle("لوحة الإحصائيات", "📊") }
                item { StatTile("إجمالي السجلات", reports.size.toString(), Icons.Default.Assignment, Modifier.fillMaxWidth()) }
                item { StatTile("أنواع الوقائع المسجلة", reports.map { it.category }.distinct().size.toString(), Icons.Default.Category, Modifier.fillMaxWidth()) }
                item { EmptyState("بيانات محلية", "الإحصائيات محسوبة من السجلات الموجودة على هذا الجهاز.") }
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, mark: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(mark, color = Flame, fontSize = 18.sp); Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}
@Composable
private fun StatTile(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(27.dp)); Spacer(Modifier.width(10.dp))
            Column { Text(value, color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black); Text(label, color = Muted, fontSize = 11.sp) }
        }
    }
}
@Composable
private fun QuickCard(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 11.sp) }
            Icon(Icons.Default.ChevronLeft, null, tint = Gold)
        }
    }
}
@Composable
private fun EmptyState(title: String, desc: String) {
    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.FolderOpen, null, tint = Gold, modifier = Modifier.size(36.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Text(desc, color = Muted, fontSize = 12.sp)
    }
}
